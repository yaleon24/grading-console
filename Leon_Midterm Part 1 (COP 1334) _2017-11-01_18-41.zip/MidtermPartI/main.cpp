#include<iostream>
using namespace std;
int main()
{
   double x, y,z,ave;
   for(int i=1;i<=30;i++){
    cin>>x>>y>>z;
    ave=(x+y+z)/3;

    if(ave<=100&&ave>=90){
        cout<<"A"<<endl;
    }
    else if(ave<=89&&ave>=80){
        cout<<"B"<<endl;
    }
     else if(ave<=79&&ave>=70){
        cout<<"C"<<endl;
    }
     else if(ave<=69&&ave>=60){
        cout<<"D"<<endl;
    }
    else if(ave<=69){
        cout<<"F"<<endl;
    }
    }


return 0;

}
